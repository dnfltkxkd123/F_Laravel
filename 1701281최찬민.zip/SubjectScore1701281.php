170281최찬민
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action='SubjectProcess1701281.php' enctype="multipart/form-data" method='post'>
		<table border='1px'>
			<tr><th colspan='2'>주요과목 점수 입력</th></tr>
			<tr>
				<td>웹프로그래밍| 점수:</td>
				<td><input name='web' type='text'></td>
			</tr>
			<tr>
				<td>자료구조실습 점수:</td>
				<td><input name='data' type='text'></td>
			</tr>
			<tr>
				<td>객체지향프로그래밍|| 점수:</td>
				<td><input name='programing' type='text'></td>
			</tr>
			<tr><th colspan='2'><input type='submit' value='전송'></th></tr>
		</table>
	</form>
	
</body>
</html>