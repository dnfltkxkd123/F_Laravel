1701281최찬민<br>
<br>
<?php
	session_start();
	unset($_SESSION['id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1>로그아웃 되었습니다.</h1>
	<a href='LoginForm1701281.php'>로그인 페이지로 이동</a><br>
</body>
</html>