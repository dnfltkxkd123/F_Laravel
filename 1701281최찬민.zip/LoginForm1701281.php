1701281최찬민
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action='LoginProcess1701281.php' enctype="multipart/form-data" method='post'>
		<table border='1px'>

			<tr>
				<td>학번:</td>
				<td><input name='id' type='text'></td>
			</tr>
			<tr>
				<td>암호:</td>
				<td><input name='pw' type='password'></td>
			</tr>
			<tr><th colspan='2'><input type='submit' value='로그인'></th></tr>
		</table>
	</form>
</body>
</html>