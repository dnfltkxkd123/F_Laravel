<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1>회원 등록에 성공했습니다.</h1>
	<a href='MemberList1701281.php'>회원목록 보기</a>
</body>
</html>